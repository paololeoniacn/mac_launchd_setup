"""
render.py — genera l'HTML stile thread Reddit + il JSON strutturato.
"""
from __future__ import annotations

import json
import logging
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from rank import TrendTopic

log = logging.getLogger(__name__)

CATEGORY_COLORS = {
    "inference":    ("#0e1f35", "#79b8ff", "#1d4173"),
    "training":     ("#2a1e0a", "#e3b341", "#4a3210"),
    "research":     ("#1a2a1a", "#3fb950", "#2d4a2d"),
    "tools":        ("#1e1a2a", "#cba6f7", "#3d2d5a"),
    "hardware":     ("#2a1010", "#f85149", "#5a1d1d"),
    "benchmark":    ("#0e2020", "#56d364", "#0d3030"),
    "architecture": ("#1a1e2a", "#58a6ff", "#1d2f4d"),
    "dataset":      ("#201a10", "#d29922", "#3a2e10"),
}
DEFAULT_COLOR = ("#161b22", "#8b949e", "#30363d")

SOURCE_ICONS = {
    "reddit": "🟠",
    "hn": "🔶",
    "arxiv": "📄",
}


def _cat_style(cat: str) -> tuple[str, str, str]:
    return CATEGORY_COLORS.get(cat, DEFAULT_COLOR)


def _render_source_pill(s: dict) -> str:
    icon = SOURCE_ICONS.get(s["source"].split("/")[0], "🔗")
    score = f" · ↑{s['score']}" if s["score"] > 0 else ""
    src_label = s["source"]
    return (
        f'<a href="{s["url"]}" target="_blank" rel="noopener" class="source-pill">'
        f'{icon} {src_label}{score}'
        f'</a>'
    )


def _render_topic(t: TrendTopic) -> str:
    bg, fg, border = _cat_style(t.category)
    tags_html = "".join(
        f'<span class="tag">{tag}</span>' for tag in t.tags
    )
    sources_html = "".join(_render_source_pill(s) for s in t.sources)
    return f"""
    <div class="topic" style="border-color:{border}; --topic-left:{fg};">
      <div class="topic-header">
        <span class="rank">#{t.rank}</span>
        <span class="cat-badge" style="background:{bg}; color:{fg}; border-color:{border};">
          {t.category}
        </span>
        <h2 class="topic-title">{t.title}</h2>
      </div>
      <div class="topic-body">
        <p class="summary">{t.summary}</p>
        <p class="why"><strong>Perché ora:</strong> {t.why_trending}</p>
      </div>
      <div class="topic-footer">
        <div class="tags">{tags_html}</div>
        <div class="sources">{sources_html}</div>
      </div>
    </div>"""


def render_html(topics: list[TrendTopic], output_path: Path) -> None:
    now = datetime.now(tz=timezone.utc)
    slot = "mattina 09:30" if now.hour < 13 else "pomeriggio 15:30"
    date_str = now.strftime("%d %B %Y")
    topics_html = "\n".join(_render_topic(t) for t in topics)

    html = f"""<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LLM Trends — {date_str} {slot}</title>
<style>
  :root {{
    --bg: #0d1117;
    --surface: #161b22;
    --border: #30363d;
    --text: #e6edf3;
    --text-dim: #c9d1d9;
    --muted: #8b949e;
    --accent: #58a6ff;
    --font: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    --mono: 'JetBrains Mono', 'Fira Code', monospace;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: var(--bg); color: var(--text); font-family: var(--font);
          font-size: 14px; line-height: 1.65; min-height: 100vh; }}

  header {{
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 14px 24px;
    display: flex; align-items: center; gap: 16px;
    position: sticky; top: 0; z-index: 50;
  }}
  header .logo {{ font-weight: 800; font-size: 18px; color: #ff6314; }}
  header .sub  {{ color: var(--accent); font-weight: 600; font-size: 13px; }}
  header .slot {{
    margin-left: auto;
    background: #21262d;
    color: var(--muted);
    font-size: 12px;
    padding: 4px 10px;
    border-radius: 12px;
    font-family: var(--mono);
  }}

  .container {{ max-width: 860px; margin: 0 auto; padding: 28px 16px; }}

  .page-title {{
    font-size: 22px; font-weight: 700;
    margin-bottom: 4px;
  }}
  .page-subtitle {{
    color: var(--muted); font-size: 13px; margin-bottom: 28px;
  }}

  .topic {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 18px 20px;
    margin-bottom: 14px;
    border-left: 3px solid var(--topic-left, var(--accent));
    transition: border-color 0.15s;
  }}
  .topic:hover {{ background: #1c2330; }}

  .topic-header {{
    display: flex; align-items: flex-start; gap: 10px;
    margin-bottom: 12px; flex-wrap: wrap;
  }}

  .rank {{
    font-family: var(--mono);
    font-size: 20px; font-weight: 800;
    color: #ff6314; min-width: 34px;
    line-height: 1.2;
  }}

  .cat-badge {{
    padding: 2px 9px; border-radius: 4px;
    font-size: 11px; font-weight: 700;
    border: 1px solid; text-transform: uppercase;
    letter-spacing: 0.06em; white-space: nowrap;
    margin-top: 3px;
  }}

  .topic-title {{
    font-size: 16px; font-weight: 600;
    color: var(--text); line-height: 1.35;
    flex: 1; min-width: 200px;
  }}

  .topic-body {{ margin-bottom: 12px; }}
  .summary {{ color: var(--text-dim); margin-bottom: 6px; }}
  .why {{ color: var(--muted); font-size: 13px; }}
  .why strong {{ color: var(--text-dim); }}

  .topic-footer {{
    display: flex; align-items: center; gap: 10px;
    flex-wrap: wrap; padding-top: 10px;
    border-top: 1px solid #21262d;
  }}

  .tags {{ display: flex; gap: 6px; flex-wrap: wrap; }}
  .tag {{
    background: #21262d; color: var(--muted);
    font-size: 11px; padding: 2px 7px; border-radius: 10px;
  }}

  .sources {{ display: flex; gap: 6px; flex-wrap: wrap; margin-left: auto; }}
  .source-pill {{
    background: #0d1117; color: var(--muted);
    border: 1px solid var(--border);
    padding: 2px 8px; border-radius: 4px;
    font-size: 11px; text-decoration: none;
    transition: color 0.1s;
  }}
  .source-pill:hover {{ color: var(--accent); border-color: var(--accent); }}

  footer {{
    margin-top: 40px;
    border-top: 1px solid var(--border);
    padding-top: 14px;
    color: var(--muted); font-size: 11px; text-align: center;
  }}

  .legend {{
    display: flex; gap: 8px; flex-wrap: wrap;
    margin-bottom: 20px;
  }}
  .legend-item {{
    font-size: 11px; color: var(--muted);
    display: flex; align-items: center; gap: 4px;
  }}
  .legend-dot {{
    width: 8px; height: 8px; border-radius: 50%;
  }}
</style>
</head>
<body>
<header>
  <span class="logo">r/</span>
  <span class="sub">LocalLLaMA · LocalLLM · ML · HN · arxiv</span>
  <span class="slot">⏱ {slot} · {date_str}</span>
</header>

<div class="container">
  <div class="page-title">🔥 Top 10 Trend Topics — {slot}</div>
  <div class="page-subtitle">
    Curati dal LLM locale · selezionati per serietà tecnica · aggiornati 2×/giorno
  </div>

  <div class="legend">
    {"".join(
      f'<span class="legend-item"><span class="legend-dot" style="background:{fg}"></span>{cat}</span>'
      for cat, (bg, fg, border) in CATEGORY_COLORS.items()
    )}
  </div>

  {topics_html if topics_html else '<p style="color:var(--muted)">Nessun topic trovato in questo run.</p>'}

  <footer>
    Generato da llm-trends · LLM: Qwen2.5-14B-Instruct-4bit (locale) ·
    Fonti: Reddit, HN, arxiv · {now.strftime("%Y-%m-%dT%H:%M:%SZ")}
  </footer>
</div>
</body>
</html>"""

    output_path.write_text(html, encoding="utf-8")
    log.info("HTML written → %s", output_path)


def render_json(topics: list[TrendTopic], output_path: Path) -> None:
    data = {
        "generated_at": datetime.now(tz=timezone.utc).isoformat(),
        "count": len(topics),
        "topics": [asdict(t) for t in topics],
    }
    output_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    log.info("JSON written → %s", output_path)
