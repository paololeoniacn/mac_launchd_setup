"""
rank.py — usa il LLM locale (porta 8080) per selezionare i 10 trend
topic più seri e tecnici, sintetizzarli e assegnarli a categorie.
Nessun guardrail nel prompt: usa logprobs=False (risposta JSON strutturata).
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

import httpx

from fetch import RawItem

log = logging.getLogger(__name__)

LLM_BASE = "http://localhost:8080"
LLM_MODEL = "mlx-community/Qwen2.5-14B-Instruct-4bit"


@dataclass
class TrendTopic:
    rank: int
    title: str
    category: str          # "inference", "training", "tools", "research", "hardware", ...
    summary: str           # 2-3 frasi sintetiche
    why_trending: str      # perché sta bucando ora
    sources: list[dict]    # [{title, url, source, score}]
    tags: list[str] = field(default_factory=list)
    fetched_at: str = ""


def _build_prompt(items: list[RawItem]) -> str:
    """
    Costruisce il prompt con i raw items. Chiede JSON puro — nessuna istruzione
    di guardrail: il controllo è nel parametro temperature=0 e nel parsing.
    """
    lines = []
    for i, it in enumerate(items[:60]):  # max 60 item in input
        score_str = f"score={it.score}" if it.score > 0 else "arxiv"
        lines.append(
            f"[{i}] [{it.source}/{it.subreddit}] [{score_str}] {it.title}"
            + (f"\n    {it.body[:200]}" if it.body else "")
        )

    items_text = "\n".join(lines)

    return f"""You are a technical research analyst specializing in AI/ML infrastructure and local LLM ecosystem.

Below is a list of posts and papers collected from Reddit (LocalLLaMA, LocalLLM, MachineLearning, artificial), Hacker News, and arxiv in the last 24 hours.

Your task: identify the 10 most technically serious and substantive trending topics. Skip hype, low-effort posts, and marketing. Prioritize: novel research findings, engineering breakthroughs, benchmark comparisons, hardware/software tooling, quantization advances, inference optimization, architecture innovations.

For each topic, synthesize across multiple sources if they cover the same theme.

Respond ONLY with a valid JSON array. No markdown, no explanation, no preamble. Schema:

[
  {{
    "rank": 1,
    "title": "concise topic title (max 80 chars)",
    "category": "one of: inference|training|research|tools|hardware|benchmark|architecture|dataset",
    "summary": "2-3 sentence technical summary of what is happening",
    "why_trending": "1 sentence on why this is getting traction right now",
    "tags": ["tag1", "tag2"],
    "source_indices": [0, 3, 7]
  }},
  ...
]

POSTS AND PAPERS:
{items_text}"""


def _call_llm(prompt: str) -> str:
    """Chiama il LLM locale con temperature=0 per output deterministico."""
    try:
        r = httpx.post(
            f"{LLM_BASE}/v1/chat/completions",
            json={
                "model": LLM_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.0,
                "top_p": 1.0,
                "max_tokens": 3000,
            },
            timeout=120,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log.error("LLM call failed: %s", e)
        return "[]"


def _extract_json(text: str) -> list[dict]:
    """Estrae il JSON anche se il modello aggiunge testo intorno."""
    # prova diretto
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # cerca il primo array JSON
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    log.warning("Could not parse LLM JSON output, returning empty list")
    return []


def rank_topics(items: list[RawItem]) -> list[TrendTopic]:
    """Chiama il LLM e ritorna i 10 trend topic strutturati."""
    if not items:
        log.warning("No items to rank")
        return []

    prompt = _build_prompt(items)
    raw = _call_llm(prompt)
    parsed = _extract_json(raw)

    now = datetime.now(tz=timezone.utc).isoformat()
    topics: list[TrendTopic] = []

    for entry in parsed[:10]:
        # risolvi gli indici sorgente
        indices = entry.get("source_indices", [])
        sources = []
        for idx in indices:
            if 0 <= idx < len(items):
                it = items[idx]
                sources.append({
                    "title": it.title,
                    "url": it.url,
                    "source": f"{it.source}/{it.subreddit}",
                    "score": it.score,
                })

        topics.append(TrendTopic(
            rank=entry.get("rank", len(topics) + 1),
            title=entry.get("title", ""),
            category=entry.get("category", "research"),
            summary=entry.get("summary", ""),
            why_trending=entry.get("why_trending", ""),
            sources=sources,
            tags=entry.get("tags", []),
            fetched_at=now,
        ))

    log.info("Ranked %d topics", len(topics))
    return topics
