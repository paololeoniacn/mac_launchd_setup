"""
fetch.py — raccoglie post/thread da Reddit, HN, arxiv senza autenticazione.
Ritorna lista di RawItem normalizzati.
"""
from __future__ import annotations

import logging
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import httpx

log = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": "llm-trends/0.1 (personal research tool)",
    "Accept": "application/json",
}

SUBREDDITS = [
    "LocalLLaMA",
    "LocalLLM",
    "MachineLearning",
    "artificial",
]

ARXIV_QUERIES = [
    "large language models",
    "local inference quantization",
    "LLM reasoning",
]


@dataclass
class RawItem:
    source: str          # "reddit", "hn", "arxiv"
    subreddit: str       # subreddit name or category
    title: str
    url: str
    score: int           # upvotes / HN points / arxiv citation proxy (0)
    comments: int
    created_utc: datetime
    body: str = ""       # selftext or abstract snippet
    tags: list[str] = field(default_factory=list)


# ── REDDIT ──────────────────────────────────────────────────────────────────

def fetch_reddit(client: httpx.Client, subreddit: str, limit: int = 25) -> list[RawItem]:
    url = f"https://www.reddit.com/r/{subreddit}/hot.json?limit={limit}&t=day"
    try:
        r = client.get(url, headers=HEADERS, timeout=15)
        r.raise_for_status()
        posts = r.json()["data"]["children"]
    except Exception as e:
        log.warning("Reddit r/%s failed: %s", subreddit, e)
        return []

    items = []
    for p in posts:
        d: dict[str, Any] = p["data"]
        # filtra stickied e pinned
        if d.get("stickied") or d.get("pinned"):
            continue
        # filtra post con pochi upvote (rumore)
        if d.get("score", 0) < 50:
            continue
        flair = d.get("link_flair_text") or ""
        body = (d.get("selftext") or "")[:600]
        items.append(RawItem(
            source="reddit",
            subreddit=subreddit,
            title=d["title"],
            url=f"https://reddit.com{d['permalink']}",
            score=d.get("score", 0),
            comments=d.get("num_comments", 0),
            created_utc=datetime.fromtimestamp(d["created_utc"], tz=timezone.utc),
            body=body,
            tags=[flair] if flair else [],
        ))
    return items


def fetch_all_reddit(client: httpx.Client) -> list[RawItem]:
    items = []
    for sub in SUBREDDITS:
        items.extend(fetch_reddit(client, sub))
    return items


# ── HACKER NEWS ─────────────────────────────────────────────────────────────

def fetch_hn(client: httpx.Client, limit: int = 30) -> list[RawItem]:
    """Usa l'API Algolia di HN — no auth, generosa."""
    queries = ["LLM", "local LLM", "language model", "AI inference", "transformer"]
    items: list[RawItem] = []
    seen: set[str] = set()

    for q in queries:
        url = (
            "https://hn.algolia.com/api/v1/search"
            f"?query={q}&tags=story&numericFilters=created_at_i>%i"
            % int((datetime.now(tz=timezone.utc).timestamp() - 86400))  # last 24h
        )
        url += f"&hitsPerPage=20"
        try:
            r = client.get(url, headers=HEADERS, timeout=15)
            r.raise_for_status()
            hits = r.json().get("hits", [])
        except Exception as e:
            log.warning("HN search '%s' failed: %s", q, e)
            continue

        for h in hits:
            oid = h.get("objectID", "")
            if oid in seen:
                continue
            seen.add(oid)
            pts = h.get("points") or 0
            if pts < 20:
                continue
            created = datetime.fromtimestamp(
                h.get("created_at_i", 0), tz=timezone.utc
            )
            items.append(RawItem(
                source="hn",
                subreddit="HackerNews",
                title=h.get("title", ""),
                url=h.get("url") or f"https://news.ycombinator.com/item?id={oid}",
                score=pts,
                comments=h.get("num_comments") or 0,
                created_utc=created,
                tags=["HN"],
            ))

    return items[:limit]


# ── ARXIV ───────────────────────────────────────────────────────────────────

def fetch_arxiv(client: httpx.Client) -> list[RawItem]:
    """
    API REST arxiv — restituisce Atom XML.
    Cerca nei titoli + abstract, ultimi 7 giorni, ordinati per data.
    """
    items: list[RawItem] = []
    seen: set[str] = set()

    for q in ARXIV_QUERIES:
        encoded = q.replace(" ", "+")
        url = (
            "https://export.arxiv.org/api/query"
            f"?search_query=ti:{encoded}+OR+abs:{encoded}"
            "&sortBy=submittedDate&sortOrder=descending&max_results=10"
        )
        try:
            r = client.get(url, headers={**HEADERS, "Accept": "application/atom+xml"}, timeout=20)
            r.raise_for_status()
        except Exception as e:
            log.warning("arxiv query '%s' failed: %s", q, e)
            continue

        ns = {
            "atom": "http://www.w3.org/2005/Atom",
            "arxiv": "http://arxiv.org/schemas/atom",
        }
        try:
            root = ET.fromstring(r.text)
        except ET.ParseError as e:
            log.warning("arxiv XML parse error: %s", e)
            continue

        for entry in root.findall("atom:entry", ns):
            title_el = entry.find("atom:title", ns)
            summary_el = entry.find("atom:summary", ns)
            id_el = entry.find("atom:id", ns)
            published_el = entry.find("atom:published", ns)

            if title_el is None or id_el is None:
                continue

            arxiv_id = (id_el.text or "").strip()
            if arxiv_id in seen:
                continue
            seen.add(arxiv_id)

            title = (title_el.text or "").strip().replace("\n", " ")
            abstract = (summary_el.text or "")[:600].strip().replace("\n", " ") if summary_el is not None else ""
            pub_str = (published_el.text or "").strip() if published_el is not None else ""
            try:
                pub_dt = datetime.fromisoformat(pub_str.replace("Z", "+00:00"))
            except ValueError:
                pub_dt = datetime.now(tz=timezone.utc)

            # link al paper
            link = arxiv_id  # già una URL tipo https://arxiv.org/abs/...

            # categorie
            cats = [
                c.get("term", "")
                for c in entry.findall("atom:category", ns)
            ]

            items.append(RawItem(
                source="arxiv",
                subreddit="arxiv",
                title=title,
                url=link,
                score=0,
                comments=0,
                created_utc=pub_dt,
                body=abstract,
                tags=cats[:3],
            ))

    return items


# ── ENTRY POINT ─────────────────────────────────────────────────────────────

def fetch_all() -> list[RawItem]:
    with httpx.Client(follow_redirects=True) as client:
        reddit = fetch_all_reddit(client)
        hn = fetch_hn(client)
        arxiv = fetch_arxiv(client)

    all_items = reddit + hn + arxiv
    log.info(
        "Fetched: %d reddit, %d HN, %d arxiv → %d total",
        len(reddit), len(hn), len(arxiv), len(all_items),
    )
    return all_items
