#!/usr/bin/env bash
# install.sh — installa llm-trends sul tuo Mac
# Esegui da dentro la cartella del progetto: bash install.sh

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USERNAME="$(whoami)"
PLIST_NAME="com.llmtrends.scheduler"
PLIST_SRC="$PROJECT_DIR/$PLIST_NAME.plist"
PLIST_DST="$HOME/Library/LaunchAgents/$PLIST_NAME.plist"

echo "=== llm-trends installer ==="
echo "Project: $PROJECT_DIR"
echo "User:    $USERNAME"
echo ""

# 1. Sostituisce YOUR_USERNAME nel plist con il vero username
sed "s|YOUR_USERNAME|$USERNAME|g" "$PLIST_SRC" > "$PLIST_DST"
echo "✓ plist installato → $PLIST_DST"

# 2. Crea venv e installa dipendenze con uv
echo "→ Installazione dipendenze uv..."
cd "$PROJECT_DIR"
uv sync
echo "✓ Dipendenze installate"

# 3. Crea log dir e output dir
mkdir -p "$PROJECT_DIR/logs" "$PROJECT_DIR/output"
echo "✓ Directory logs/ e output/ create"

# 4. Carica il launchd agent
if launchctl list | grep -q "$PLIST_NAME"; then
  launchctl unload "$PLIST_DST" 2>/dev/null || true
fi
launchctl load -w "$PLIST_DST"
echo "✓ launchd agent caricato"

echo ""
echo "=== Installazione completata ==="
echo ""
echo "Comandi utili:"
echo "  Test immediato:      uv run --project $PROJECT_DIR $PROJECT_DIR/run.py"
echo "  Apri ultimo output:  open $PROJECT_DIR/output/latest.html"
echo "  Log in tempo reale:  tail -f $PROJECT_DIR/logs/trends.log"
echo "  Stato launchd:       launchctl list | grep llmtrends"
echo "  Rimuovi daemon:      launchctl unload $PLIST_DST && rm $PLIST_DST"
