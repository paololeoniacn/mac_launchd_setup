#!/usr/bin/env python3
"""
run.py — entrypoint chiamato da launchd.
Fetch → Rank → Render JSON + HTML.
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

# aggiungi src/ al path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from fetch import fetch_all
from rank import rank_topics
from render import render_html, render_json

# ── logging ─────────────────────────────────────────────────────────────────
LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(LOG_DIR / "trends.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("llm-trends")

# ── output paths ─────────────────────────────────────────────────────────────
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

# file "latest" (sempre sovrascritto — apri questo nel browser)
HTML_LATEST = OUTPUT_DIR / "latest.html"
JSON_LATEST  = OUTPUT_DIR / "latest.json"

# archivio con timestamp
def _ts() -> str:
    return datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M")


def main() -> None:
    ts = _ts()
    log.info("=== llm-trends run start [%s] ===", ts)

    # 1. Fetch
    items = fetch_all()
    if not items:
        log.error("No items fetched — aborting")
        sys.exit(1)

    # 2. Rank via LLM
    topics = rank_topics(items)
    if not topics:
        log.error("LLM returned no topics — aborting")
        sys.exit(1)

    # 3. Render
    render_html(topics, HTML_LATEST)
    render_json(topics, JSON_LATEST)

    # archivio
    render_html(topics, OUTPUT_DIR / f"trends_{ts}.html")
    render_json(topics, OUTPUT_DIR / f"trends_{ts}.json")

    log.info("=== run complete — %d topics ===", len(topics))


if __name__ == "__main__":
    main()
